package com.praktikum.Data;

public class DataStore {
}
