package com.praktikum.actions;

import java.util.Scanner;

public interface AdminActions {
    void manageItems(Scanner scanner);
    void manageUsers(Scanner scanner);
}
