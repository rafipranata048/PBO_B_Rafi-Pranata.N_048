package com.praktikum.gui;

public class MahasiswaDashboard {
}
