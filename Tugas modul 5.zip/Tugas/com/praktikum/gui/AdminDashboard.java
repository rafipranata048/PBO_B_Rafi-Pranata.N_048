package com.praktikum.gui;

public class AdminDashboard {
}
