package com.praktikum.gui;

public class MainApp {
}
