package com.praktikum.users;
import com.praktikum.actions.AdminActions;
import com.praktikum.Item;
import com.praktikum.Data;

import java.util.Scanner;

public class Admin extends User implements AdminActions{

    private String Username ;
   private String Password ;

   public Admin(String nama, String nim, String username, String password ){
       super(nama, nim);
       this.Username = username;
       this.Password = password;
   }

   @Override
    public boolean login(String inputUsername, String inputPassword ){ //dgn nama metode
        return inputUsername.equals(Username) && inputPassword.equals(Password);
    }

    @Override
    public void displayInfo(){
       System.out.println("login admin berhasil");
    }

    @Override
    public void manageItems() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Lihat Semua Laporan");
        System.out.println("2. Tandai Barang Diambil");
        int pilihan = scanner.nextInt();
        scanner.nextLine();

        switch (pilihan) {
            case 1:
                for (int i = 0; i < Data.reportedItems.size(); i++) {
                    Item item = Data.reportedItems.get(i);
                    System.out.println(i + ". " + item.getItemName() + " | " + item.getLocation() + " | " + item.getStatus());
                }
                break;

            case 2:
                System.out.println("Pilih indeks barang yang ingin ditandai sebagai 'Claimed': ");
                for (int i = 0; i < Data.reportedItems.size(); i++) {
                    Item item = Data.reportedItems.get(i);
                    if ("Reported".equals(item.getStatus())) {
                        System.out.println(i + ". " + item.getItemName());
                    }
                }

                try {
                    int index = scanner.nextInt();
                    Item item = Data.reportedItems.get(index);
                    if ("Reported".equals(item.getStatus())) {
                        item.setStatus("Claimed");
                        System.out.println("Barang berhasil ditandai sebagai diambil.");
                    } else {
                        System.out.println("Barang sudah di-claim.");
                    }
                } catch (Exception e) {
                    System.out.println("Indeks tidak valid!");
                }
                break;
            default:
                System.out.println("Pilihan tidak valid.");
        }
    }

    @Override
    public void manageUsers() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Tambah Mahasiswa");
        System.out.println("2. Hapus Mahasiswa");
        int pilihan = scanner.nextInt();
        scanner.nextLine();

        switch (pilihan) {
            case 1:
                System.out.print("Nama: ");
                String nama = scanner.nextLine();
                System.out.print("NIM : ");
                String nim = scanner.nextLine();
                Data.userList.add(new Mahasiswa(nama, nim));
                System.out.println("Mahasiswa berhasil ditambahkan.");
                break;

            case 2:
                System.out.print("NIM Mahasiswa: ");
                String nimHapus = scanner.nextLine();
                boolean found = false;
                for (int i = 0; i < Data.userList.size(); i++) {
                    User u = Data.userList.get(i);
                    if (u instanceof Mahasiswa mhs && mhs.getNim().equals(nimHapus)) {
                        Data.userList.remove(i);
                        System.out.println("Mahasiswa berhasil dihapus.");
                        found = true;
                        break;
                    }
                }
                if (!found) System.out.println("Mahasiswa tidak ditemukan.");
                break;
            default:
                System.out.println("Pilihan tidak valid.");
        }
    }

    @Override
    public void displayAppMenu(){
        Scanner scanner = new Scanner(System.in);
        boolean login = true;
        while (login){
            System.out.println("Menu Admin: ");
            System.out.println("1. Kelola Laporan Barang");
            System.out.println("2. Kelola Data Mahasiswa");
            System.out.println("0. Logout");

            System.out.println("Pilih Menu: ");
            int pilihan = scanner.nextInt();

            switch (pilihan){
                case 1:
                    manageItems();
                    break;
                case 2:
                    manageUsers();
                    break;
                case 0:
                    login = false;
                     break;
                default:
                    System.out.println("Pilihan Tidak Valid");
                    break;
            }
        }
    }
}
