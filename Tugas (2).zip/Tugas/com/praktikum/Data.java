package com.praktikum;

import com.praktikum.users.User;
import com.praktikum.Item;

import java.util.ArrayList;

public class Data {
    public static ArrayList<User> userList = new ArrayList<>();
    public static ArrayList<Item> reportedItems =new ArrayList<>();
}
