package com.praktikum.actions;

public interface AdminActions {
    void manageItems();
    void manageUsers();
}
