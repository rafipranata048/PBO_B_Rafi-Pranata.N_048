class KarakterGame {//membuat class dgn nama KarakterGame yang akan dioveride oleh kelas lain
    private String nama; // Mendeklarasikan dua atribut privat nama dan kesehatan
    private int kesehatan;// menyimpan nilai kesehatan dari karakter

    public KarakterGame(String nama, int kesehatan) { // Menginisialisasi objek dengan nama dan kesehatan.
        this.nama = nama;//
        this.kesehatan = kesehatan;
    }
//Getter & Setter untuk mengakses dan mengubah nilai atribut nama dan kesehatan.
    public String getNama() { //
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getKesehatan() {
        return kesehatan;
    }

    public void setKesehatan(int kesehatan) {
        this.kesehatan = kesehatan;
    }

    public void serang(KarakterGame target) { //Method serang Akan di-override di subclass (Pahlawan dan Musuh)
    }
}

// Kelas Pahlawan (Subclass dari KarakterGame)
class Pahlawan extends KarakterGame {
    public Pahlawan(String nama, int kesehatan) { //Membuat kelas Pahlawan yang mewarisi KarakterGame.
        super(nama, kesehatan); //Memanggil constructor superclass menggunakan super
    }

    @Override //Override method serang untuk mendefinisikan serangan spesifik.
    public void serang(KarakterGame target) {
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan pedang!");//Menampilkan teks bahwa pahlawan menyerang musuh dengan pedang.
        target.setKesehatan(target.getKesehatan() - 20);//Mengurangi kesehatan target sebesar 20
        System.out.println("Kesehatan " + target.getNama() + " sekarang: " + target.getKesehatan());//Menampilkan kesehatan target setelah diserang.
    }
}

// Kelas Musuh (Subclass dari KarakterGame)
class Musuh extends KarakterGame {
    public Musuh(String nama, int kesehatan) {//menginisialisasi nama dan kesehatan.
        super(nama, kesehatan);
    }

    @Override //Override method serang untuk mendefinisikan serangan musuh.
    public void serang(KarakterGame target) {
        System.out.println(getNama() + " menyerang " + target.getNama() + " menggunakan sihir!");//Menampilkan teks bahwa musuh menyerang pahlawan dengan sihir.
        target.setKesehatan(target.getKesehatan() - 15);//Mengurangi kesehatan target sebesar 15.
        System.out.println("Kesehatan " + target.getNama() + " sekarang: " + target.getKesehatan());//Menampilkan kesehatan target setelah diserang.

    }
}

// Kelas Main (Kelas Utama)
public class Main { //Method main sebagai titik awal program.
    public static void main(String[] args) {
        // Membuat objek
        KarakterGame karakterUmum = new KarakterGame("Karakter Umum", 100);//Membuat objek karakter umum dengan kesehatan 100
        Pahlawan pahlawan = new Pahlawan("Brimstone", 150);//Membuat objek pahlawan dgn nama brimstone dgn kesehatan 150
        Musuh musuh = new Musuh("Viper", 200);//membuat objek musuh dgn nama viper dgn kesehatan awal 200

        // Menampilkan status awal kesehatan
        System.out.println("Status Awal Kesehatan:");
        System.out.println(pahlawan.getNama() + " Kesehatan: " + pahlawan.getKesehatan());//Menampilkan kesehatan awal dari pahlawan Brimstone
        System.out.println(musuh.getNama() + " Kesehatan: " + musuh.getKesehatan());//Menampilkan kesehatan awal dari musuh

        // Simulasi pertarungan
        System.out.println("\nPertarungan Dimulai!");//memberi tahu bahwa pertarungan telah dimulai
        pahlawan.serang(musuh); // Pahlawan (Brimstone) menyerang Viper
        musuh.serang(pahlawan);  // musuh  (Viper) menyerang Brimstone
    }
}