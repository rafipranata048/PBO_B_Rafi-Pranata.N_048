public class StokTidakCukupException extends Exception {
  public StokTidakCukupException(String message) {

    super(message);
  }
}
